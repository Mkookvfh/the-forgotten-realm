Mint OBJ conversion package

Open or import open-world-dark-fantasy.obj. Keep the textures folder beside the OBJ file so materials can resolve their image files.
